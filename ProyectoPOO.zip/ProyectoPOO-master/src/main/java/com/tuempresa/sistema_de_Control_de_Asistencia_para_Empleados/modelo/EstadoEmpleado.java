package com.tuempresa.sistema_de_Control_de_Asistencia_para_Empleados.modelo;

public enum EstadoEmpleado {
    ACTIVO,
    INACTIVO,
    SUSPENDIDO
}
